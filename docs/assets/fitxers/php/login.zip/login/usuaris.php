<?php
// En una aplicació real, açò estaria en la base de dades.
// Els hash s'han generat amb: php -r 'echo password_hash("Secret123", PASSWORD_DEFAULT);'
return [
    "ana" => '$2y$10$s4doXGBHudCgrUFdIaSUgOEI.h3euOBS0okhtU.iB/JE.hl.sBQxG',
];
