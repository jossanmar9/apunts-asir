<?php
session_start();
$usuaris = require "usuaris.php";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuari = $_POST["usuari"] ?? "";
    $clau   = $_POST["clau"] ?? "";

    if (isset($usuaris[$usuari]) && password_verify($clau, $usuaris[$usuari])) {
        session_regenerate_id(true);          // nou identificador de sessió (seguretat)
        $_SESSION["usuari"] = $usuari;
        header("Location: privada.php");
        exit;
    }
    $error = "Usuari o contrasenya incorrectes.";
}
?>
<!DOCTYPE html>
<html lang="ca"><head><meta charset="UTF-8"><title>Entrar</title></head>
<body>
    <h1>Entrar</h1>
    <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
    <form method="post">
        <label>Usuari <input name="usuari" required></label>
        <label>Contrasenya <input type="password" name="clau" required></label>
        <button>Entrar</button>
    </form>
</body></html>
