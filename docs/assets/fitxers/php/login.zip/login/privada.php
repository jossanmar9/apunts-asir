<?php
session_start();
if (!isset($_SESSION["usuari"])) {          // no ha entrat: a la pàgina d'entrada
    header("Location: login.php");
    exit;
}
$_SESSION["visites"] = ($_SESSION["visites"] ?? 0) + 1;
?>
<!DOCTYPE html>
<html lang="ca"><head><meta charset="UTF-8"><title>Zona privada</title></head>
<body>
    <h1>Hola, <?= htmlspecialchars($_SESSION["usuari"]) ?></h1>
    <p>Has visitat esta pàgina <?= $_SESSION["visites"] ?> vegades en esta sessió.</p>
    <p><a href="logout.php">Eixir</a></p>
</body></html>
