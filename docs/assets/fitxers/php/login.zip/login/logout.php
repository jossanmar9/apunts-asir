<?php
session_start();
$_SESSION = [];
session_destroy();
setcookie(session_name(), "", time() - 3600, "/");   // esborrar la galeta de sessió
header("Location: login.php");
exit;
