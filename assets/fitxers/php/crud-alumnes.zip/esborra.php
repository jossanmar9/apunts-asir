<?php
require __DIR__ . "/db.php";

$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);
if ($_SERVER["REQUEST_METHOD"] === "POST" && $id) {
    $stmt = bd()->prepare("DELETE FROM alumnes WHERE id = ?");
    $stmt->execute([$id]);
}
header("Location: index.php");
exit;
