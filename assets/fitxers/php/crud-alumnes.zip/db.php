<?php
function bd(): PDO
{
    static $pdo = null;                       // una sola connexió per petició
    if ($pdo === null) {
        $c = require __DIR__ . "/config.php";
        $pdo = new PDO($c["dsn"], $c["user"], $c["clau"], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}

function e(?string $text): string             // escapar per a HTML
{
    return htmlspecialchars($text ?? "", ENT_QUOTES, "UTF-8");
}
