<?php
require __DIR__ . "/db.php";

$alumnes = bd()->query(
    "SELECT a.id, a.nom, a.cognoms, a.poblacio, c.nom AS cicle
     FROM alumnes a LEFT JOIN cicles c ON c.codi = a.cicle
     ORDER BY a.cognoms"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="ca">
<head><meta charset="UTF-8"><link rel="stylesheet" href="estil.css"><title>Alumnes</title></head>
<body>
    <h1>Alumnes</h1>
    <p><a href="form.php">+ Nou alumne</a></p>
    <table>
        <tr><th>Cognoms</th><th>Nom</th><th>Població</th><th>Cicle</th><th></th></tr>
        <?php foreach ($alumnes as $a): ?>
        <tr>
            <td><?= e($a["cognoms"]) ?></td>
            <td><?= e($a["nom"]) ?></td>
            <td><?= e($a["poblacio"]) ?></td>
            <td><?= e($a["cicle"] ?? "—") ?></td>
            <td>
                <a href="form.php?id=<?= $a["id"] ?>">Editar</a>
                <form method="post" action="esborra.php" style="display:inline"
                      onsubmit="return confirm('Segur?')">
                    <input type="hidden" name="id" value="<?= $a["id"] ?>">
                    <button>Esborrar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
