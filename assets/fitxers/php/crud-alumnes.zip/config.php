<?php
// Dades de connexió. En producció, fora del DocumentRoot o en variables d'entorn.
return [
    "dsn"   => "pgsql:host=127.0.0.1;port=5433;dbname=institut",
    "user"  => "app",
    "clau"  => "canvia-la",
];
