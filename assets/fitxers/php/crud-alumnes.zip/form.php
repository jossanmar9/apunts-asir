<?php
require __DIR__ . "/db.php";

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT) ?: null;   // si hi ha id: editar
$alumne = ["nom" => "", "cognoms" => "", "poblacio" => "", "cicle" => ""];
$errors = [];

if ($id) {
    $stmt = bd()->prepare("SELECT nom, cognoms, poblacio, cicle FROM alumnes WHERE id = ?");
    $stmt->execute([$id]);
    $alumne = $stmt->fetch() ?: exit("No existix l'alumne $id");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $alumne = [
        "nom"      => trim($_POST["nom"] ?? ""),
        "cognoms"  => trim($_POST["cognoms"] ?? ""),
        "poblacio" => trim($_POST["poblacio"] ?? ""),
        "cicle"    => $_POST["cicle"] ?: null,
    ];
    if ($alumne["nom"] === "")     $errors[] = "Falta el nom.";
    if ($alumne["cognoms"] === "") $errors[] = "Falten els cognoms.";

    if (!$errors) {
        if ($id) {
            $stmt = bd()->prepare("UPDATE alumnes SET nom = :nom, cognoms = :cognoms,
                                   poblacio = :poblacio, cicle = :cicle WHERE id = :id");
            $stmt->execute($alumne + ["id" => $id]);
        } else {
            $stmt = bd()->prepare("INSERT INTO alumnes (nom, cognoms, poblacio, cicle)
                                   VALUES (:nom, :cognoms, :poblacio, :cicle)");
            $stmt->execute($alumne);
        }
        header("Location: index.php");          // patró PRG: Post → Redirect → Get
        exit;
    }
}

$cicles = bd()->query("SELECT codi, nom FROM cicles ORDER BY nom")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ca">
<head><meta charset="UTF-8"><link rel="stylesheet" href="estil.css"><title><?= $id ? "Editar" : "Nou" ?> alumne</title></head>
<body>
    <h1><?= $id ? "Editar" : "Nou" ?> alumne</h1>
    <?php foreach ($errors as $err): ?><p class="error"><?= e($err) ?></p><?php endforeach; ?>
    <form method="post">
        <label>Nom <input name="nom" value="<?= e($alumne["nom"]) ?>"></label>
        <label>Cognoms <input name="cognoms" value="<?= e($alumne["cognoms"]) ?>"></label>
        <label>Població <input name="poblacio" value="<?= e($alumne["poblacio"]) ?>"></label>
        <label>Cicle
            <select name="cicle">
                <option value="">—</option>
                <?php foreach ($cicles as $c): ?>
                    <option value="<?= e($c["codi"]) ?>" <?= $c["codi"] === $alumne["cicle"] ? "selected" : "" ?>>
                        <?= e($c["nom"]) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <button>Guardar</button> <a href="index.php">Cancel·lar</a>
    </form>
</body>
</html>
